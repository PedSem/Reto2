create
    definer = root@localhost procedure ej3()
BEGIN
DECLARE vcodemp int default 0;
DECLARE fin INT DEFAULT 0;
DECLARE vnumHi int;

DECLARE curemp CURSOR FOR SELECT CodEmp from empleado;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET fin=1;
DECLARE EXIT HANDLER FOR sqlexception rollback;

START TRANSACTION;
OPEN curemp;
FETCH curemp INTO vcodemp;
while (fin=0) DO
update empleado set NumHi = ej2(vcodemp) where CodEmp = vcodemp;
FETCH curemp INTO vcodemp;
END WHILE;
COMMIT;
CLOSE curemp;
END;

